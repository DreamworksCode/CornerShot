import React from 'react'
import Report from 'src/views/form-layouts/Report'

const index = () => {
  return (
    <div>
      <Report/>
    </div>
  )
}

export default index
