import React from 'react'
import BaseTable from 'src/views/tables/BaseTable'

const index = () => {
  return (
    <BaseTable/>
  )
}

export default index
