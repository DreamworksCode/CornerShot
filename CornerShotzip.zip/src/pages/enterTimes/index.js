import React from 'react'
import EnterTimes from 'src/views/form-layouts/EnterTimes'

const index = () => {
  return (
    <div>
      <EnterTimes/>
    </div>
  )
}

export default index
